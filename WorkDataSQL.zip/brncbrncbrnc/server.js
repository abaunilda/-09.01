const express = require('express');
const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// EJS настройка
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Инициализация базы данных
const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: 'database.sqlite',
});

// Модели
const Product = sequelize.define('Product', {
    name: { type: DataTypes.STRING, allowNull: false },
    price: { type: DataTypes.FLOAT, allowNull: false },
});

const Category = sequelize.define('Category', {
    name: { type: DataTypes.STRING, allowNull: false },
});

const Supplier = sequelize.define('Supplier', {
    name: { type: DataTypes.STRING, allowNull: false },
    contact: { type: DataTypes.STRING },
});

// Связи между таблицами
Product.belongsTo(Category);
Product.belongsTo(Supplier);
Category.hasMany(Product);
Supplier.hasMany(Product);

// Маршруты
app.get('/', async (req, res) => {
    try {
        const products = await Product.findAll({
            include: [Category, Supplier],
        });
        res.render('index', { products });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/add-category', (req, res) => {
    res.render('add-category');
});

app.get('/add-supplier', (req, res) => {
    res.render('add-supplier');
});

app.get('/add-product', async (req, res) => {
    try {
        const categories = await Category.findAll();
        const suppliers = await Supplier.findAll();
        res.render('add-product', { categories, suppliers });
    } catch (error) {
        console.error('Error fetching categories or suppliers:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/edit-product/:id', async (req, res) => {
    try {
        const productId = req.params.id;
        const product = await Product.findByPk(productId, {
            include: [Category, Supplier],
        });
        const categories = await Category.findAll();
        const suppliers = await Supplier.findAll();
        res.render('edit-product', { product, categories, suppliers });
    } catch (error) {
        console.error('Error fetching product for edit:', error);
        res.status(500).send('Internal Server Error');
    }
});

// POST маршруты
app.post('/add-category', async (req, res) => {
    const { name } = req.body;
    if (name) {
        await Category.create({ name });
    }
    res.redirect('/');
});

app.post('/add-supplier', async (req, res) => {
    const { name, contact } = req.body;
    if (name) {
        await Supplier.create({ name, contact });
    }
    res.redirect('/');
});

app.post('/add-product', async (req, res) => {
    const { name, price, categoryId, supplierId } = req.body;
    if (name && price && categoryId && supplierId) {
        try {
            await Product.create({
                name,
                price: parseFloat(price),
                CategoryId: categoryId,
                SupplierId: supplierId,
            });
            res.redirect('/');
        } catch (error) {
            console.error('Error adding product:', error);
            res.status(500).send('Internal Server Error');
        }
    } else {
        res.status(400).send('All fields are required');
    }
});

app.post('/edit-product/:id', async (req, res) => {
    try {
        const productId = req.params.id;
        const { name, price, categoryId, supplierId } = req.body;

        await Product.update(
            { 
                name, 
                price: parseFloat(price), 
                CategoryId: categoryId, 
                SupplierId: supplierId 
            },
            { where: { id: productId } }
        );
        res.redirect('/');
    } catch (error) {
        console.error('Error updating product:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/delete-product/:id', async (req, res) => {
    try {
        const productId = req.params.id;
        await Product.destroy({ where: { id: productId } });
        res.redirect('/');
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).send('Internal Server Error');
    }
});

// Инициализация и запуск сервера
async function initializeApp() {
    try {
        await sequelize.sync({ force: true });
        console.log('Database synchronized');

        // Создание тестовых данных
        const category1 = await Category.create({ name: 'Electronics' });
        const category2 = await Category.create({ name: 'Books' });

        const supplier1 = await Supplier.create({ name: 'TechCorp', contact: 'techcorp@example.com' });
        const supplier2 = await Supplier.create({ name: 'BookStore', contact: 'contact@bookstore.com' });

        await Product.create({ 
            name: 'Laptop', 
            price: 120.99, 
            CategoryId: category1.id, 
            SupplierId: supplier1.id 
        });
        await Product.create({ 
            name: 'Smartphone', 
            price: 799.49, 
            CategoryId: category1.id, 
            SupplierId: supplier1.id 
        });
        await Product.create({ 
            name: 'Science Fiction Book', 
            price: 19.99, 
            CategoryId: category2.id, 
            SupplierId: supplier2.id 
        });

        console.log('Test data created');

        // Запуск сервера
        app.listen(PORT, () => {
            console.log(`Server is running on http://localhost:${PORT}`);
        });

    } catch (error) {
        console.error('Error initializing the application:', error);
    }
}

// Запуск приложения
initializeApp();