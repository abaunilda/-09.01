// Подтверждение удаления
document.addEventListener('DOMContentLoaded', function () {
    const deleteForms = document.querySelectorAll('form[action*="delete-product"]');

    deleteForms.forEach(form => {
        form.addEventListener('submit', function (e) {
            if (!confirm('Вы уверены, что хотите удалить этот продукт?')) {
                e.preventDefault();
            }
        });
    });

    // Анимация загрузки
    const buttons = document.querySelectorAll('button[type="submit"]');
    buttons.forEach(button => {
        button.addEventListener('click', function () {
            if (this.form.checkValidity()) {
                this.innerHTML = 'Загрузка...';
                this.disabled = true;
            }
        });
    });
});