// routes/admin.js
const express = require('express');
const db = require('../models');
const router = express.Router();

// Защита: только админ
router.use((req, res, next) => {
  if (!req.session.user || req.session.user.role !== 'admin') {
    return res.status(403).send('Доступ запрещён. Требуются права администратора.');
  }
  next();
});

// Дашборд
router.get('/', (req, res) => {
  res.render('admin/dashboard');
});

// Маппинг таблиц к моделям
const modelMap = {
  users: db.User,
  roles: db.Role,
  positions: db.Position,
  vehicles: db.Vehicle,
  orders: db.Order
};

const includeMap = {
  users: [{ model: db.Role }, { model: db.Position }],
  orders: [{ model: db.User }, { model: db.Vehicle }]
};

// Просмотр таблицы
router.get('/:table', async (req, res) => {
  const { table } = req.params;
  const Model = modelMap[table];
  if (!Model) return res.status(404).send('Таблица не найдена');
  const records = await Model.findAll({ include: includeMap[table] || [] });
  res.render(`admin/${table}`, { records, table });
});

// Специальные маршруты для users и orders
router.get('/users/new', async (req, res) => {
  const roles = await db.Role.findAll();
  const positions = await db.Position.findAll();
  res.render('admin/users_form', { record: null, table: 'users', roles, positions });
});

router.get('/users/:id/edit', async (req, res) => {
  const { id } = req.params;
  const record = await db.User.findByPk(id);
  if (!record) return res.status(404).send('Пользователь не найден');
  const roles = await db.Role.findAll();
  const positions = await db.Position.findAll();
  res.render('admin/users_form', { record, table: 'users', roles, positions });
});

router.get('/orders/new', async (req, res) => {
  const users = await db.User.findAll();
  const vehicles = await db.Vehicle.findAll();
  res.render('admin/orders_form', { record: null, table: 'orders', users, vehicles });
});

router.get('/orders/:id/edit', async (req, res) => {
  const { id } = req.params;
  const record = await db.Order.findByPk(id);
  if (!record) return res.status(404).send('Заказ не найден');
  const users = await db.User.findAll();
  const vehicles = await db.Vehicle.findAll();
  res.render('admin/orders_form', { record, table: 'orders', users, vehicles });
});

// Общие маршруты для остальных таблиц (roles, positions, vehicles)
router.get('/:table/new', (req, res) => {
  const { table } = req.params;
  // Пропускаем users и orders — они обработаны выше
  if (['users', 'orders'].includes(table)) return;
  if (!modelMap[table]) return res.status(404).send('Таблица не найдена');
  res.render(`admin/${table}_form`, { record: null, table });
});

router.get('/:table/:id/edit', async (req, res) => {
  const { table, id } = req.params;
  if (['users', 'orders'].includes(table)) return;
  const Model = modelMap[table];
  if (!Model) return res.status(404).send('Таблица не найдена');
  const record = await Model.findByPk(id);
  if (!record) return res.status(404).send('Запись не найдена');
  res.render(`admin/${table}_form`, { record, table });
});

// Создание записи (для ВСЕХ таблиц)
router.post('/:table', async (req, res) => {
  const { table } = req.params;
  const Model = modelMap[table];
  if (!Model) return res.status(404).send('Таблица не найдена');
  try {
    await Model.create(req.body);
    res.redirect(`/admin/${table}`);
  } catch (err) {
    res.status(500).send(`Ошибка: ${err.message}`);
  }
});

// Обновление записи (для ВСЕХ таблиц)
router.post('/:table/:id', async (req, res) => {
  const { table, id } = req.params;
  const Model = modelMap[table];
  if (!Model) return res.status(404).send('Таблица не найдена');
  const record = await Model.findByPk(id);
  if (!record) return res.status(404).send('Запись не найдена');
  try {
    await record.update(req.body);
    res.redirect(`/admin/${table}`);
  } catch (err) {
    res.status(500).send(`Ошибка: ${err.message}`);
  }
});

// Удаление записи (для ВСЕХ таблиц)
router.post('/:table/:id/delete', async (req, res) => {
  const { table, id } = req.params;
  const Model = modelMap[table];
  if (!Model) return res.status(404).send('Таблица не найдена');
  const record = await Model.findByPk(id);
  if (!record) return res.status(404).send('Запись не найдена');
  try {
    await record.destroy();
    res.redirect(`/admin/${table}`);
  } catch (err) {
    res.status(500).send(`Ошибка удаления: возможно, есть связанные данные.`);
  }
});

module.exports = router;