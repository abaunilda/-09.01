const { Sequelize } = require('sequelize');
const path = require('path');

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, '..', 'database.sqlite')
});

const db = {};
db.sequelize = sequelize;
db.User = require('./User')(sequelize);
db.Role = require('./Role')(sequelize);
db.Position = require('./Position')(sequelize);
db.Order = require('./Order')(sequelize);
db.Vehicle = require('./Vehicle')(sequelize);

// Связи
db.Role.hasMany(db.User, { foreignKey: 'roleId', onDelete: 'CASCADE' });
db.User.belongsTo(db.Role, { foreignKey: 'roleId' });

db.Position.hasMany(db.User, { foreignKey: 'positionId' });
db.User.belongsTo(db.Position, { foreignKey: 'positionId' });

db.User.hasMany(db.Order, { foreignKey: 'userId' });
db.Order.belongsTo(db.User, { foreignKey: 'userId' });

db.Vehicle.hasMany(db.Order, { foreignKey: 'vehicleId' });
db.Order.belongsTo(db.Vehicle, { foreignKey: 'vehicleId' });

module.exports = db;