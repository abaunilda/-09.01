// app.js
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
const db = require('./models');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Сессии
app.use(session({
  secret: 'transport-secret-key-2025',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // true только при HTTPS
}));

// Middleware для передачи пользователя в шаблоны
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// Роуты
app.use('/admin', require('./routes/admin'));

// В app.js, после middleware сессии

// Главная
app.get('/', (req, res) => {
  res.render('index');
});

// Просмотр таблиц для всех (включая клиентов)
app.get('/view/:table', async (req, res) => {
  const { table } = req.params;
  const modelMap = {
    users: db.User,
    roles: db.Role,
    positions: db.Position,
    vehicles: db.Vehicle,
    orders: db.Order
  };
  const Model = modelMap[table];
  if (!Model) return res.status(404).send('Таблица не найдена');

  const includeMap = {
    users: [{ model: db.Role }, { model: db.Position }],
    orders: [{ model: db.User }, { model: db.Vehicle }]
  };

  const records = await Model.findAll({ include: includeMap[table] || [] });
  // Передаём данные в шаблон с префиксом "view_"
  res.render(`view_${table}`, { records, table });
});

// Логин
app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  // Упрощённая аутентификация (в реальном проекте — хеширование!)
  if (email === 'admin@trans.com' && password === 'admin123') {
    req.session.user = { id: 1, email, role: 'admin' };
    return res.redirect('/admin');
  }
  if (email === 'client@trans.com' && password === 'client123') {
    req.session.user = { id: 2, email, role: 'client' };
    return res.redirect('/');
  }

  res.render('login', { error: 'Неверный email или пароль' });
});

// Выход
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

// Инициализация БД и запуск
db.sequelize.sync({ force: true }).then(async () => {
  console.log('БД пересоздана');
  // Создаём роли
  await db.Role.bulkCreate([
    { name: 'admin' },
    { name: 'client' }
  ]);
  // Создаём должности
  await db.Position.bulkCreate([
    { title: 'Менеджер' },
    { title: 'Водитель' },
    { title: 'Диспетчер' }
  ]);
  // Создаём тестовых пользователей
  const roles = await db.Role.findAll();
  const positions = await db.Position.findAll();
  await db.User.create({
    fullName: 'Админ Иван',
    email: 'admin@trans.com',
    phone: '+79991112233',
    roleId: roles[0].id,
    positionId: positions[0].id
  });
  await db.User.create({
    fullName: 'Клиент ООО "Груз"',
    email: 'client@trans.com',
    phone: '+79994445566',
    roleId: roles[1].id,
    positionId: positions[2].id
  });
  console.log('Тестовые данные добавлены');
}).finally(() => {
  app.listen(PORT, () => {
    console.log(`🚀 Сервер запущен: http://localhost:${PORT}`);
    console.log('Логин админа: admin@trans.com / admin123');
    console.log('Логин клиента: client@trans.com / client123');
  });
});