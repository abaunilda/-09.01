const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  return sequelize.define('Pricing', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    vehicleType: { type: DataTypes.STRING, allowNull: false },
    pricePerKm: { type: DataTypes.DECIMAL(10,2), allowNull: false },
    minPrice: { type: DataTypes.DECIMAL(10,2), allowNull: false }
  }, { tableName: 'Pricing' });
};