const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  return sequelize.define('Driver', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    userId: { type: DataTypes.INTEGER, allowNull: false },
    licenseNumber: { type: DataTypes.STRING, allowNull: false },
    experience: { type: DataTypes.INTEGER, defaultValue: 0 },
    rating: { type: DataTypes.DECIMAL(3,2), defaultValue: 5.0 },
    isAvailable: { type: DataTypes.BOOLEAN, defaultValue: true }
  }, { tableName: 'Drivers' });
};