const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  return sequelize.define('Order', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    pickupAddress: { type: DataTypes.STRING, allowNull: false },
    deliveryAddress: { type: DataTypes.STRING, allowNull: false },
    distance: { type: DataTypes.DECIMAL(10,2) },
    cargoWeight: { type: DataTypes.DECIMAL(10,2) },
    cargoType: { type: DataTypes.STRING },
    status: { type: DataTypes.STRING, defaultValue: 'created' },
    totalCost: { type: DataTypes.DECIMAL(10,2) },
    userId: { type: DataTypes.INTEGER, allowNull: false },
    vehicleId: { type: DataTypes.INTEGER },
    driverId: { type: DataTypes.INTEGER },
    orderDate: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
  }, { tableName: 'Orders' });
};