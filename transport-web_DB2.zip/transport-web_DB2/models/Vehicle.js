const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  return sequelize.define('Vehicle', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    model: { type: DataTypes.STRING, allowNull: false },
    licensePlate: { type: DataTypes.STRING, unique: true, allowNull: false },
    capacityKg: { type: DataTypes.INTEGER, allowNull: false },
    isAvailable: { type: DataTypes.BOOLEAN, defaultValue: true }
  }, { tableName: 'Vehicles' });
};