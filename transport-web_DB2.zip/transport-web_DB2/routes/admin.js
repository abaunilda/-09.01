const express = require('express');
const db = require('../models');
const router = express.Router();

// Middleware проверки админских прав
router.use((req, res, next) => {
  if (!req.session.user || req.session.user.role !== 'admin') {
    return res.status(403).render('403', { title: 'Доступ запрещен' });
  }
  next();
});

// Дашборд админа
router.get('/', async (req, res) => {
  try {
    const stats = {
      totalUsers: await db.User.count(),
      totalOrders: await db.Order.count(),
      totalVehicles: await db.Vehicle.count(),
      totalDrivers: await db.Driver.count(),
      recentOrders: await db.Order.findAll({
        include: [{ model: db.User }, { model: db.Vehicle }],
        order: [['orderDate', 'DESC']],
        limit: 5
      })
    };
    
    res.render('admin/dashboard', {
      title: 'Админ панель',
      stats
    });
  } catch (err) {
    res.render('admin/dashboard', {
      title: 'Админ панель',
      stats: {},
      error: 'Ошибка загрузки статистики'
    });
  }
});

// Маппинг таблиц
const modelMap = {
  users: { model: db.User, includes: [{ model: db.Role }, { model: db.Position }] },
  roles: { model: db.Role },
  positions: { model: db.Position },
  vehicles: { model: db.Vehicle },
  orders: { model: db.Order, includes: [{ model: db.User }, { model: db.Vehicle }, { model: db.Driver, include: [{ model: db.User }] }] },
  drivers: { model: db.Driver, includes: [{ model: db.User }] },
  pricing: { model: db.Pricing }
};

// CRUD для всех таблиц
router.get('/:table', async (req, res) => {
  const { table } = req.params;
  const tableConfig = modelMap[table];
  
  if (!tableConfig) {
    return res.status(404).render('404', { title: 'Таблица не найдена' });
  }
  
  try {
    const records = await tableConfig.model.findAll({
      include: tableConfig.includes || []
    });
    
    res.render(`admin/table`, {
      title: `Управление ${getTableTitle(table)}`,
      records,
      table,
      tableTitle: getTableTitle(table)
    });
  } catch (err) {
    res.render(`admin/table`, {
      title: `Управление ${getTableTitle(table)}`,
      records: [],
      table,
      error: 'Ошибка загрузки данных: ' + err.message
    });
  }
});

// Формы создания/редактирования
router.get('/:table/new', async (req, res) => {
  const { table } = req.params;
  res.render(`admin/form`, {
    title: `Добавить ${getTableTitle(table)}`,
    table,
    record: null,
    relatedData: await getRelatedData(table)
  });
});

router.get('/:table/:id/edit', async (req, res) => {
  const { table, id } = req.params;
  const tableConfig = modelMap[table];
  
  try {
    const record = await tableConfig.model.findByPk(id, {
      include: tableConfig.includes || []
    });
    
    if (!record) {
      return res.status(404).render('404', { title: 'Запись не найдена' });
    }
    
    res.render(`admin/form`, {
      title: `Редактировать ${getTableTitle(table)}`,
      table,
      record,
      relatedData: await getRelatedData(table)
    });
  } catch (err) {
    res.redirect(`/admin/${table}`);
  }
});

// Создание записи
router.post('/:table', async (req, res) => {
  const { table } = req.params;
  const tableConfig = modelMap[table];
  
  try {
    await tableConfig.model.create(req.body);
    res.redirect(`/admin/${table}`);
  } catch (err) {
    res.render(`admin/form`, {
      title: `Добавить ${getTableTitle(table)}`,
      table,
      record: null,
      relatedData: await getRelatedData(table),
      error: 'Ошибка создания: ' + err.message
    });
  }
});

// Обновление записи
router.post('/:table/:id', async (req, res) => {
  const { table, id } = req.params;
  const tableConfig = modelMap[table];
  
  try {
    const record = await tableConfig.model.findByPk(id);
    if (!record) {
      return res.status(404).render('404', { title: 'Запись не найдена' });
    }
    
    await record.update(req.body);
    res.redirect(`/admin/${table}`);
  } catch (err) {
    res.render(`admin/form`, {
      title: `Редактировать ${getTableTitle(table)}`,
      table,
      record: await tableConfig.model.findByPk(id),
      relatedData: await getRelatedData(table),
      error: 'Ошибка обновления: ' + err.message
    });
  }
});

// Удаление записи
router.post('/:table/:id/delete', async (req, res) => {
  const { table, id } = req.params;
  const tableConfig = modelMap[table];
  
  try {
    const record = await tableConfig.model.findByPk(id);
    if (!record) {
      return res.status(404).render('404', { title: 'Запись не найдена' });
    }
    
    await record.destroy();
    res.redirect(`/admin/${table}`);
  } catch (err) {
    res.redirect(`/admin/${table}?error=Ошибка удаления`);
  }
});

// Вспомогательные функции
function getTableTitle(table) {
  const titles = {
    users: 'пользователями',
    roles: 'ролями',
    positions: 'должностями',
    vehicles: 'транспортом',
    orders: 'заказами',
    drivers: 'водителями',
    pricing: 'тарифами'
  };
  return titles[table] || table;
}

async function getRelatedData(table) {
  const data = {};
  
  if (table === 'users') {
    data.roles = await db.Role.findAll();
    data.positions = await db.Position.findAll();
  } else if (table === 'orders') {
    data.users = await db.User.findAll();
    data.vehicles = await db.Vehicle.findAll();
    data.drivers = await db.Driver.findAll({ include: [{ model: db.User }] });
  } else if (table === 'drivers') {
    data.users = await db.User.findAll({ 
      include: [{ model: db.Role, where: { name: 'driver' } }]
    });
  }
  
  return data;
}

module.exports = router;