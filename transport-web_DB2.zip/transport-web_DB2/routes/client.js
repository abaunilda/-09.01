const express = require('express');
const db = require('../models');
const router = express.Router();

// Middleware проверки авторизации клиента
router.use((req, res, next) => {
  if (!req.session.user || req.session.user.role === 'admin') {
    return res.redirect('/login');
  }
  next();
});

// Профиль клиента
router.get('/profile', async (req, res) => {
  try {
    const orders = await db.Order.findAll({ 
      where: { userId: req.session.user.id },
      include: [
        { model: db.Vehicle },
        { model: db.Driver, include: [{ model: db.User }] }
      ],
      order: [['orderDate', 'DESC']],
      limit: 5
    });
    
    res.render('client/profile', { 
      title: 'Мой профиль',
      orders 
    });
  } catch (err) {
    res.render('client/profile', { 
      title: 'Мой профиль',
      orders: [],
      error: 'Ошибка загрузки данных'
    });
  }
});

// Создание заказа
router.get('/new-order', async (req, res) => {
  try {
    const vehicles = await db.Vehicle.findAll({ where: { isAvailable: true } });
    const drivers = await db.Driver.findAll({ 
      where: { isAvailable: true },
      include: [{ model: db.User }]
    });
    const pricing = await db.Pricing.findAll();
    
    res.render('client/new-order', {
      title: 'Новый заказ',
      vehicles,
      drivers,
      pricing
    });
  } catch (err) {
    res.render('client/new-order', {
      title: 'Новый заказ',
      vehicles: [],
      drivers: [],
      pricing: [],
      error: 'Ошибка загрузки данных'
    });
  }
});

// Расчет стоимости
router.post('/calculate-price', async (req, res) => {
  try {
    const { distance, vehicleType, cargoWeight } = req.body;
    
    const pricing = await db.Pricing.findOne({ where: { vehicleType } });
    if (!pricing) {
      return res.json({ error: 'Тариф не найден' });
    }
    
    let totalCost = parseFloat(distance) * parseFloat(pricing.pricePerKm);
    totalCost = Math.max(totalCost, parseFloat(pricing.minPrice));
    
    // Надбавка за вес
    if (parseFloat(cargoWeight) > 1000) {
      totalCost *= 1.2; // +20% за тяжелый груз
    }
    
    res.json({ totalCost: totalCost.toFixed(2) });
  } catch (err) {
    res.json({ error: 'Ошибка расчета' });
  }
});

// Создание заказа
router.post('/create-order', async (req, res) => {
  try {
    const { pickupAddress, deliveryAddress, distance, cargoWeight, cargoType, vehicleId, driverId, totalCost } = req.body;
    
    const order = await db.Order.create({
      pickupAddress,
      deliveryAddress,
      distance: parseFloat(distance),
      cargoWeight: parseFloat(cargoWeight),
      cargoType,
      totalCost: parseFloat(totalCost),
      userId: req.session.user.id,
      vehicleId: parseInt(vehicleId),
      driverId: parseInt(driverId),
      status: 'confirmed'
    });
    
    // Обновляем доступность транспорта и водителя
    await db.Vehicle.update({ isAvailable: false }, { where: { id: vehicleId } });
    await db.Driver.update({ isAvailable: false }, { where: { id: driverId } });
    
    res.redirect('/client/profile');
  } catch (err) {
    const vehicles = await db.Vehicle.findAll({ where: { isAvailable: true } });
    const drivers = await db.Driver.findAll({ 
      where: { isAvailable: true },
      include: [{ model: db.User }]
    });
    
    res.render('client/new-order', {
      title: 'Новый заказ',
      vehicles,
      drivers,
      error: 'Ошибка создания заказа: ' + err.message
    });
  }
});

// История заказов
router.get('/orders', async (req, res) => {
  try {
    const orders = await db.Order.findAll({ 
      where: { userId: req.session.user.id },
      include: [
        { model: db.Vehicle },
        { model: db.Driver, include: [{ model: db.User }] }
      ],
      order: [['orderDate', 'DESC']]
    });
    
    res.render('client/orders', {
      title: 'Мои заказы',
      orders
    });
  } catch (err) {
    res.render('client/orders', {
      title: 'Мои заказы',
      orders: [],
      error: 'Ошибка загрузки заказов'
    });
  }
});

module.exports = router;