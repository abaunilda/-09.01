const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
const db = require('./models');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Сессии
app.use(session({
  secret: 'transport-company-secret-2025',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// Middleware для передачи пользователя в шаблоны
app.use(async (req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// Роуты
app.use('/admin', require('./routes/admin'));
app.use('/client', require('./routes/client'));

// Главная страница
app.get('/', (req, res) => {
  res.render('index', { 
    title: 'Транспортная компания "Грузовик"',
    user: req.session.user 
  });
});

// Услуги
app.get('/services', (req, res) => {
  res.render('services', { title: 'Наши услуги' });
});

// Контакты
app.get('/contacts', (req, res) => {
  res.render('contacts', { title: 'Контакты' });
});

// О компании
app.get('/about', (req, res) => {
  res.render('about', { title: 'О компании' });
});

// Регистрация
app.get('/register', (req, res) => {
  if (req.session.user) {
    return res.redirect('/profile');
  }
  res.render('auth/register', { 
    title: 'Регистрация',
    error: null 
  });
});

app.post('/register', async (req, res) => {
  const { fullName, email, phone, password, role } = req.body;
  
  try {
    const existingUser = await db.User.findOne({ where: { email } });
    if (existingUser) {
      return res.render('auth/register', { 
        error: 'Пользователь с таким email уже существует',
        title: 'Регистрация'
      });
    }
    
    const clientRole = await db.Role.findOne({ where: { name: role || 'client' } });
    const clientPosition = await db.Position.findOne({ where: { title: 'Клиент' } });
    
    const user = await db.User.create({
      fullName,
      email,
      phone,
      roleId: clientRole.id,
      positionId: clientPosition.id
    });
    
    // Если регистрируется водитель
    if (role === 'driver') {
      await db.Driver.create({
        userId: user.id,
        licenseNumber: 'DL' + Date.now(),
        experience: 0,
        isAvailable: true
      });
    }
    
    req.session.user = {
      id: user.id,
      email: user.email,
      role: role || 'client',
      fullName: user.fullName,
      phone: user.phone
    };
    
    res.redirect('/client/profile');
  } catch (err) {
    res.render('auth/register', { 
      error: 'Ошибка регистрации: ' + err.message,
      title: 'Регистрация'
    });
  }
});

// Авторизация
app.get('/login', (req, res) => {
  if (req.session.user) {
    return res.redirect('/profile');
  }
  res.render('auth/login', { 
    title: 'Вход в систему',
    error: null 
  });
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  
  try {
    // Упрощенная аутентификация (в реальном проекте - хеширование!)
    if (email === 'admin@trans.com' && password === 'admin123') {
      const adminUser = await db.User.findOne({ 
        where: { email },
        include: [{ model: db.Role }]
      });
      
      req.session.user = { 
        id: adminUser.id, 
        email, 
        role: 'admin',
        fullName: adminUser.fullName,
        phone: adminUser.phone
      };
      return res.redirect('/admin');
    }
    
    // Поиск пользователя в БД
    const user = await db.User.findOne({ 
      where: { email },
      include: [{ model: db.Role }]
    });
    
    if (user) {
      // В реальном проекте проверка хеша пароля
      req.session.user = {
        id: user.id,
        email: user.email,
        role: user.Role.name,
        fullName: user.fullName,
        phone: user.phone
      };
      
      if (user.Role.name === 'admin') {
        return res.redirect('/admin');
      } else {
        return res.redirect('/client/profile');
      }
    }
    
    res.render('auth/login', { 
      error: 'Неверный email или пароль',
      title: 'Вход в систему'
    });
  } catch (err) {
    res.render('auth/login', { 
      error: 'Ошибка входа: ' + err.message,
      title: 'Вход в систему'
    });
  }
});

// Профиль (редирект)
app.get('/profile', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  if (req.session.user.role === 'admin') {
    return res.redirect('/admin');
  }
  return res.redirect('/client/profile');
});

// Выход
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

// 404 обработчик
app.use((req, res) => {
  res.status(404).render('404', { title: 'Страница не найдена' });
});

// Инициализация БД
async function initializeDatabase() {
  try {
    await db.sequelize.sync({ force: true });
    console.log('📦 База данных инициализирована');
    
    // Создаём роли
    await db.Role.bulkCreate([
      { name: 'admin' },
      { name: 'client' },
      { name: 'driver' }
    ]);
    
    // Создаём должности
    await db.Position.bulkCreate([
      { title: 'Менеджер' },
      { title: 'Водитель' },
      { title: 'Диспетчер' },
      { title: 'Клиент' }
    ]);
    
    // Тарифы
    await db.Pricing.bulkCreate([
      { vehicleType: 'Газель', pricePerKm: 25.00, minPrice: 500.00 },
      { vehicleType: 'Каблук', pricePerKm: 20.00, minPrice: 400.00 },
      { vehicleType: 'Фургон', pricePerKm: 35.00, minPrice: 700.00 },
      { vehicleType: 'Грузовик', pricePerKm: 50.00, minPrice: 1000.00 }
    ]);
    
    // Тестовый админ
    const adminRole = await db.Role.findOne({ where: { name: 'admin' } });
    const managerPosition = await db.Position.findOne({ where: { title: 'Менеджер' } });
    
    await db.User.create({
      fullName: 'Администратор Системы',
      email: 'admin@trans.com',
      phone: '+79991112233',
      roleId: adminRole.id,
      positionId: managerPosition.id
    });
    
    // Тестовый клиент
    const clientRole = await db.Role.findOne({ where: { name: 'client' } });
    const clientPosition = await db.Position.findOne({ where: { title: 'Клиент' } });
    
    await db.User.create({
      fullName: 'Тестовый Клиент',
      email: 'client@test.com',
      phone: '+79994445566',
      roleId: clientRole.id,
      positionId: clientPosition.id
    });
    
    // Тестовый транспорт
    await db.Vehicle.bulkCreate([
      { model: 'ГАЗель NEXT', licensePlate: 'А123БВ777', capacityKg: 1500, isAvailable: true },
      { model: 'Hyundai HD78', licensePlate: 'В456ГН777', capacityKg: 3500, isAvailable: true },
      { model: 'Ford Transit', licensePlate: 'Е789КХ777', capacityKg: 1200, isAvailable: true }
    ]);
    
    console.log('✅ Тестовые данные добавлены');
    console.log('👤 Админ: admin@trans.com / admin123');
    console.log('👤 Клиент: client@test.com / любой пароль');
    
  } catch (error) {
    console.error('❌ Ошибка инициализации БД:', error);
  }
}

// Запуск сервера
initializeDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`🚀 Сервер запущен: http://localhost:${PORT}`);
  });
});

module.exports = app;