function showMessage(elementId, message, type) {
    const element = document.getElementById(elementId);
    element.textContent = message;
    element.className = `message ${type}`;
    element.style.display = 'block';

    if (type === 'success') {
        setTimeout(() => {
            element.style.display = 'none';
        }, 3000);
    }
}

function hideAllCards() {
    document.getElementById('loginCard').style.display = 'none';
    document.getElementById('registerCard').style.display = 'none';
    document.getElementById('userCard').style.display = 'none';
}

function showLoginForm() {
    hideAllCards();
    document.getElementById('loginCard').style.display = 'block';
    clearMessages();
    document.getElementById('loginForm').reset();
}

function showRegisterForm() {
    hideAllCards();
    document.getElementById('registerCard').style.display = 'block';
    clearMessages();
    document.getElementById('registerFormElement').reset();
}

function showUserCard() {
    hideAllCards();
    document.getElementById('userCard').style.display = 'block';
}

function clearMessages() {
    document.getElementById('message').style.display = 'none';
    document.getElementById('registerMessage').style.display = 'none';
}

document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const submitButton = e.target.querySelector('.submit-button');
    const originalText = submitButton.querySelector('.button-text').textContent;

    submitButton.querySelector('.button-text').textContent = 'Вход...';
    submitButton.disabled = true;
    
    const formData = new FormData(e.target);
    const data = {
        email: formData.get('email'),
        password: formData.get('password')
    };

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            showMessage('message', 'Успешный вход', 'success');
            setTimeout(() => {
                displayUserInfo(result.user, result.history);
            }, 1000);
        } else {
            showMessage('message', result.error, 'error');
        }
    } catch (error) {
        showMessage('message', 'Ошибка сети. Проверьте подключение.', 'error');
    } finally {

        submitButton.querySelector('.button-text').textContent = originalText;
        submitButton.disabled = false;
    }
});

document.getElementById('registerFormElement').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const submitButton = e.target.querySelector('.submit-button');
    const originalText = submitButton.querySelector('.button-text').textContent;

    submitButton.querySelector('.button-text').textContent = 'Регистрация...';
    submitButton.disabled = true;
    
    const formData = new FormData(e.target);
    const data = {
        username: formData.get('username'),
        email: formData.get('email'),
        password: formData.get('password')
    };

    try {
        const response = await fetch('/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            showMessage('registerMessage', 'Регистрация успешно завершена', 'success');
            setTimeout(() => {
                showLoginForm();
            }, 1500);
        } else {
            showMessage('registerMessage', result.error, 'error');
        }
    } catch (error) {
        showMessage('registerMessage', 'Ошибка сети. Проверьте подключение.', 'error');
    } finally {
        submitButton.querySelector('.button-text').textContent = originalText;
        submitButton.disabled = false;
    }
});

function displayUserInfo(user, history) {
    document.getElementById('welcomeMessage').textContent = `${user.username} • ${user.email}`;
    
    const historyElement = document.getElementById('loginHistory');
    if (history && history.length > 0) {
        historyElement.innerHTML = history.map(entry => 
            `<div class="history-item">
                <div>${new Date(entry.loginAt).toLocaleString('ru-RU')}</div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
                    IP: ${entry.ipAddress || 'Неизвестно'}
                </div>
            </div>`
        ).join('');
    } else {
        historyElement.innerHTML = '<div class="history-empty">История входов отсутствует</div>';
    }
    
    showUserCard();
}

function logout() {
    showLoginForm();
}


document.addEventListener('DOMContentLoaded', function() {

    document.getElementById('loginForm').reset();
    document.getElementById('registerFormElement').reset();
    clearMessages();

    showLoginForm();
});