const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const { sequelize, User, LoginHistory } = require('./models');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.post('/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;

        const existingUser = await User.findOne({ 
            where: { email } 
        });

        if (existingUser) {
            return res.status(400).json({ 
                error: 'Пользователь с таким email уже существует' 
            });
        }

        const user = await User.create({
            username,
            email,
            password
        });

        res.status(201).json({ 
            message: 'Пользователь успешно создан',
            user: { id: user.id, username: user.username, email: user.email }
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ 
            error: 'Ошибка при регистрации' 
        });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ 
            where: { email } 
        });

        if (!user) {
            return res.status(401).json({ 
                error: 'Неверный email или пароль' 
            });
        }

        const isValidPassword = await user.validatePassword(password);
        
        if (!isValidPassword) {
            return res.status(401).json({ 
                error: 'Неверный email или пароль' 
            });
        }

        const ipAddress = req.ip || req.connection.remoteAddress;
        
        await LoginHistory.create({
            userId: user.id,
            ipAddress: ipAddress
        });

        const loginHistory = await LoginHistory.findAll({
            where: { userId: user.id },
            order: [['loginAt', 'DESC']],
            limit: 10
        });

        res.json({
            message: 'Успешный вход',
            user: {
                id: user.id,
                username: user.username,
                email: user.email
            },
            history: loginHistory.map(entry => ({
                loginAt: entry.loginAt,
                ipAddress: entry.ipAddress
            }))
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ 
            error: 'Ошибка при входе' 
        });
    }
});

async function startServer() {
    try {
        await sequelize.authenticate();
        console.log('Connection to database has been established successfully.');
        
        await sequelize.sync({ force: false });
        console.log('Database synchronized');
        
        app.listen(PORT, () => {
            console.log(`Server is running on http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error('Unable to start server:', error);
    }
}

startServer();