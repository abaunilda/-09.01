const sequelize = require('../config/database');
const User = require('./User');
const LoginHistory = require('./LoginHistory');

User.hasMany(LoginHistory, { foreignKey: 'userId' });
LoginHistory.belongsTo(User, { foreignKey: 'userId' });

module.exports = {
  sequelize,
  User,
  LoginHistory
};