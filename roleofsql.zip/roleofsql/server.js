import express from 'express';
import session from 'express-session';
import bodyParser from 'body-parser';
import { Sequelize, DataTypes } from 'sequelize';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcrypt';

// Правильное получение __dirname для ES модулей
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Настройка SQLite базы данных
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, 'database.sqlite'),
  logging: console.log
});

// Модель Role
const Role = sequelize.define('Role', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  }
}, {
  tableName: 'roles',
  timestamps: false
});

// Модель User
const User = sequelize.define('User', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  login: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  roleId: {
    type: DataTypes.INTEGER,
    references: {
      model: Role,
      key: 'id',
    },
    allowNull: false,
  }
}, {
  tableName: 'users',
  timestamps: true
});

// Ассоциации между моделями
Role.hasMany(User, { foreignKey: 'roleId' });
User.belongsTo(Role, { foreignKey: 'roleId' });

// Хеширование пароля перед сохранением
User.beforeSave(async (user) => {
  if (user.changed('password')) {
    user.password = await bcrypt.hash(user.password, 10);
  }
});

// Метод для проверки пароля
User.prototype.checkPassword = async function(password) {
  return await bcrypt.compare(password, this.password);
};

const app = express();

// Настройка EJS как шаблонизатора
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

// Настройка сессий
app.use(
  session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
  })
);

app.use(express.static(path.join(__dirname, 'public')));

// Middleware аутентификации
function isAuthenticated(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Middleware проверки роли
function hasRole(roleName) {
  return async (req, res, next) => {
    if (!req.session.user) {
      return res.redirect('/login');
    }

    try {
      const user = await User.findByPk(req.session.user.id, { 
        include: Role 
      });
      
      if (user && user.Role.name === roleName) {
        return next();
      } else {
        res.status(403).send('Доступ запрещен');
      }
    } catch (error) {
      console.error('Role check error:', error);
      res.status(500).send('Ошибка сервера');
    }
  };
}

// Инициализация базы данных
async function initializeDatabase() {
  try {
    await sequelize.sync({ force: false });
    console.log('✅ Database synchronized successfully');
    
    // Создаем стандартные роли если их нет
    const roles = ['Администратор', 'Модератор', 'Пользователь'];
    for (const roleName of roles) {
      await Role.findOrCreate({ where: { name: roleName } });
    }
    console.log('✅ Default roles created');
  } catch (error) {
    console.error('❌ Database sync error:', error);
  }
}

// Маршруты

// Главная страница
app.get('/', (req, res) => {
  res.render('index', { user: req.session.user });
});

// Страница регистрации
app.get('/register', async (req, res) => {
  try {
    const roles = await Role.findAll();
    res.render('register', { roles });
  } catch (error) {
    console.error('Error loading roles:', error);
    res.status(500).send('Ошибка сервера');
  }
});

// Обработка регистрации
app.post('/register', async (req, res) => {
  const { login, password, roleId } = req.body;
  
  try {
    // Проверяем существование роли
    const role = await Role.findByPk(roleId);
    if (!role) {
      return res.status(400).send('Роль не найдена');
    }

    // Проверяем нет ли уже пользователя с таким логином
    const existingUser = await User.findOne({ where: { login } });
    if (existingUser) {
      return res.status(400).send('Пользователь с таким логином уже существует');
    }

    // Создаем пользователя
    const user = await User.create({ 
      login, 
      password,
      roleId: parseInt(roleId) 
    });

    console.log(`✅ New user registered: ${login}`);
    res.redirect('/login');
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).send('Ошибка регистрации: ' + error.message);
  }
});

// Страница входа
app.get('/login', (req, res) => {
  res.render('login');
});

// Обработка входа
app.post('/login', async (req, res) => {
  const { login, password } = req.body;
  
  try {
    const user = await User.findOne({ 
      where: { login }, 
      include: Role 
    });

    if (user && await user.checkPassword(password)) {
      req.session.user = { 
        id: user.id, 
        login: user.login, 
        role: user.Role.name 
      };
      console.log(`✅ User logged in: ${login}`);
      return res.redirect('/profile');
    } else {
      console.log(`❌ Failed login attempt for: ${login}`);
      res.status(401).send('Неверный логин или пароль');
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).send('Ошибка сервера: ' + error.message);
  }
});

// Выход из системы
app.get('/logout', (req, res) => {
  console.log(`✅ User logged out: ${req.session.user?.login}`);
  req.session.destroy((err) => {
    if (err) {
      console.error('Logout error:', err);
    }
    res.redirect('/');
  });
});

// Страница профиля
app.get('/profile', isAuthenticated, (req, res) => {
  res.render('profile', { user: req.session.user });
});

// Админ панель
app.get('/admin', isAuthenticated, hasRole('Администратор'), (req, res) => {
  res.render('admin', { user: req.session.user });
});

// Панель модератора
app.get('/moderator', isAuthenticated, hasRole('Модератор'), (req, res) => {
  res.render('moderator', { user: req.session.user });
});

// Панель пользователя
app.get('/user-panel', isAuthenticated, hasRole('Пользователь'), (req, res) => {
  res.render('user-panel', { user: req.session.user });
});

// Запуск сервера
const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  await initializeDatabase();
});