import express from 'express';
import session from 'express-session';
import bodyParser from 'body-parser';
import { Sequelize, DataTypes } from 'sequelize';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcrypt';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, 'database.sqlite'),
  logging: console.log
});

const Role = sequelize.define('Role', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  }
}, {
  tableName: 'roles',
  timestamps: false
});

const User = sequelize.define('User', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  login: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  roleId: {
    type: DataTypes.INTEGER,
    references: {
      model: Role,
      key: 'id',
    },
    allowNull: false,
  }
}, {
  tableName: 'users',
  timestamps: true
});

Role.hasMany(User, { foreignKey: 'roleId' });
User.belongsTo(Role, { foreignKey: 'roleId' });

User.beforeSave(async (user) => {
  if (user.changed('password')) {
    user.password = await bcrypt.hash(user.password, 10);
  }
});

User.prototype.checkPassword = async function(password) {
  return await bcrypt.compare(password, this.password);
};

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

app.use(
  session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
  })
);

app.use(express.static(path.join(__dirname, 'public')));

function isAuthenticated(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    res.redirect('/login');
  }
}

function hasRole(roleName) {
  return async (req, res, next) => {
    if (!req.session.user) {
      return res.redirect('/login');
    }

    try {
      const user = await User.findByPk(req.session.user.id, { 
        include: Role 
      });
      
      if (user && user.Role.name === roleName) {
        return next();
      } else {
        res.status(403).send('Доступ запрещен');
      }
    } catch (error) {
      console.error('Role check error:', error);
      res.status(500).send('Ошибка сервера');
    }
  };
}

async function initializeDatabase() {
  try {
    await sequelize.sync({ force: false });
    console.log('Database synchronized successfully');

    const roles = ['Администратор', 'Модератор', 'Пользователь'];
    for (const roleName of roles) {
      await Role.findOrCreate({ where: { name: roleName } });
    }
    console.log('Default roles created');
  } catch (error) {
    console.error('Database sync error:', error);
  }
}

app.get('/', (req, res) => {
  res.render('index', { user: req.session.user });
});

app.get('/register', async (req, res) => {
  try {
    const roles = await Role.findAll();
    res.render('register', { roles });
  } catch (error) {
    console.error('Error loading roles:', error);
    res.status(500).send('Ошибка сервера');
  }
});

app.post('/register', async (req, res) => {
  const { login, password, roleId } = req.body;
  
  try {
    const role = await Role.findByPk(roleId);
    if (!role) {
      return res.status(400).send('Роль не найдена');
    }

    const existingUser = await User.findOne({ where: { login } });
    if (existingUser) {
      return res.status(400).send('Пользователь с таким логином уже существует');
    }

    const user = await User.create({ 
      login, 
      password,
      roleId: parseInt(roleId) 
    });

    console.log(`New user registered: ${login}`);
    res.redirect('/login');
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).send('Ошибка регистрации: ' + error.message);
  }
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', async (req, res) => {
  const { login, password } = req.body;
  
  try {
    const user = await User.findOne({ 
      where: { login }, 
      include: Role 
    });

    if (user && await user.checkPassword(password)) {
      req.session.user = { 
        id: user.id, 
        login: user.login, 
        role: user.Role.name 
      };
      console.log(`User logged in: ${login}`);
      return res.redirect('/profile');
    } else {
      console.log(`Failed login attempt for: ${login}`);
      res.status(401).send('Неверный логин или пароль');
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).send('Ошибка сервера: ' + error.message);
  }
});

app.get('/logout', (req, res) => {
  console.log(`User logged out: ${req.session.user?.login}`);
  req.session.destroy((err) => {
    if (err) {
      console.error('Logout error:', err);
    }
    res.redirect('/');
  });
});

app.get('/profile', isAuthenticated, (req, res) => {
  res.render('profile', { user: req.session.user });
});

app.get('/admin', isAuthenticated, hasRole('Администратор'), (req, res) => {
  res.render('admin', { user: req.session.user });
});

app.get('/moderator', isAuthenticated, hasRole('Модератор'), (req, res) => {
  res.render('moderator', { user: req.session.user });
});

app.get('/user-panel', isAuthenticated, hasRole('Пользователь'), (req, res) => {
  res.render('user-panel', { user: req.session.user });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
  console.log(`Server running on http://localhost:${PORT}`);
  await initializeDatabase();
});