const readline = require('readline');
const db = require('./models');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function showMenu() {
    console.log('\n=== Управление БД транспортной компании ===');
    console.log('1. Показать все записи в таблице');
    console.log('2. Изменить несколько записей в таблице');
    console.log('3. Изменить одну запись по ID');
    console.log('4. Каскадное удаление роли');
    console.log('5. Выход');
    rl.question('Выберите действие (1-5): ', handleMenuChoice);
}

async function handleMenuChoice(choice) {
    switch (choice.trim()) {
        case '1':
            await showAllRecords();
            break;
        case '2':
            await updateMultipleRecords();
            break;
        case '3':
            await updateSingleRecord();
            break;
        case '4':
            await cascadeDeleteRole();
            break;
        case '5':
            console.log('Выход из программы...');
            await db.sequelize.close();
            rl.close();
            return;
        default:
            console.log('Неверный выбор. Попробуйте снова.');
    }
    if (choice.trim() !== '5') {
        showMenu();
    }
}

async function showAllRecords() {
    const table = await askTable();
    if (!table) return;

    try {
        let records;
        if (table === 'User') records = await db.User.findAll({ include: [db.Role, db.Position] });
        else if (table === 'Role') records = await db.Role.findAll();
        else if (table === 'Position') records = await db.Position.findAll();
        else if (table === 'Order') records = await db.Order.findAll({ include: [db.User, db.Vehicle] });
        else if (table === 'Vehicle') records = await db.Vehicle.findAll();

        console.log(`\n📋 Записи в таблице "${table}":`);
        records.forEach(rec => console.log(`ID: ${rec.id}`, rec.get({ plain: true })));
        if (records.length === 0) console.log('Нет записей.');
    } catch (err) {
        console.error('Ошибка при чтении:', err.message);
    }
}

async function updateMultipleRecords() {
    const table = await askTable();
    if (!table) return;

    if (table !== 'User') {
        console.log(' Изменение нескольких записей доступно только для таблицы "User" (например, обновить телефон у всех клиентов).');
        return;
    }

    console.log('Пример: обновить поле "phone" у всех пользователей с roleId = 3 (клиенты)');
    const roleId = await ask('Введите roleId для фильтрации: ');
    const newPhone = await ask('Введите новый номер телефона: ');

    try {
        const [count] = await db.User.update(
            { phone: newPhone },
            { where: { roleId: parseInt(roleId) } }
        );
        console.log(`Обновлено ${count} записей.`);
    } catch (err) {
        console.error('Ошибка при обновлении:', err.message);
    }
}

async function updateSingleRecord() {
    const table = await askTable();
    if (!table) return;

    const id = await ask(`Введите ID записи в таблице "${table}": `);
    const recordId = parseInt(id);

    let record;
    try {
        if (table === 'User') record = await db.User.findByPk(recordId);
        else if (table === 'Role') record = await db.Role.findByPk(recordId);
        else if (table === 'Position') record = await db.Position.findByPk(recordId);
        else if (table === 'Order') record = await db.Order.findByPk(recordId);
        else if (table === 'Vehicle') record = await db.Vehicle.findByPk(recordId);

        if (!record) {
            console.log('Запись не найдена.');
            return;
        }

        console.log('Текущие данные:', record.get({ plain: true }));

        const field = await ask('Какое поле изменить? (например: email, phone, name, model): ');
        const newValue = await ask(`Новое значение для "${field}": `);

        await record.update({ [field]: newValue });
        console.log('Запись обновлена.');
    } catch (err) {
        console.error('Ошибка при обновлении:', err.message);
    }
}

async function cascadeDeleteRole() {
    const roles = await db.Role.findAll();
    console.log('\nДоступные роли:');
    roles.forEach(r => console.log(`ID: ${r.id}, Название: ${r.name}`));

    const id = await ask('Введите ID роли для удаления (каскадно): ');
    const roleId = parseInt(id);

    try {
        const role = await db.Role.findByPk(roleId);
        if (!role) {
            console.log('Роль не найдена.');
            return;
        }

        const userCount = await db.User.count({ where: { roleId } });
        console.log(`ℹ️  Перед удалением: ${userCount} пользователей с этой ролью.`);

        await role.destroy();

        const userCountAfter = await db.User.count({ where: { roleId } });
        console.log(`Роль "${role.name}" удалена. Осталось пользователей с этой ролью: ${userCountAfter}`);
    } catch (err) {
        console.error('Ошибка при удалении:', err.message);
    }
}

function askTable() {
    return new Promise((resolve) => {
        rl.question(
            'Выберите таблицу (User, Role, Position, Order, Vehicle): ',
            (answer) => {
                const table = answer.trim();
                if (!['User', 'Role', 'Position', 'Order', 'Vehicle'].includes(table)) {
                    console.log('Неверное имя таблицы.');
                    resolve(null);
                } else {
                    resolve(table);
                }
            }
        );
    });
}

function ask(question) {
    return new Promise((resolve) => {
        rl.question(question, (answer) => resolve(answer.trim()));
    });
}

async function init() {
    try {
        await db.sequelize.sync();
        console.log('Подключение к БД установлено.');

        const roleCount = await db.Role.count();
        if (roleCount === 0) {
            console.log('База пуста. Создаём тестовые данные...');
            await db.Role.bulkCreate([
                { name: 'admin' },
                { name: 'driver' },
                { name: 'client' }
            ]);
            await db.Position.bulkCreate([
                { title: 'Менеджер' },
                { title: 'Водитель' },
                { title: 'Диспетчер' }
            ]);
            const roles = await db.Role.findAll();
            const positions = await db.Position.findAll();
            await db.User.create({
                fullName: 'Иван Петров',
                email: 'ivan@example.com',
                phone: '+79001112233',
                roleId: roles[0].id,
                positionId: positions[0].id
            });
            await db.User.create({
                fullName: 'Анна Сидорова',
                email: 'anna@example.com',
                phone: '+79004445566',
                roleId: roles[1].id,
                positionId: positions[1].id
            });
            console.log('Тестовые данные добавлены.');
        }

        showMenu();
    } catch (err) {
        console.error('Ошибка инициализации:', err.message);
        rl.close();
    }
}

init();