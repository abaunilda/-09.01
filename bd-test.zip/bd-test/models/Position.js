const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const Position = sequelize.define('Position', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        title: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
        },
    }, {
        tableName: 'Positions',
        timestamps: true,
    });
    return Position;
};