const express = require('express');
const db = require('./models');

const app = express();
app.use(express.json());

app.get('/users', async (req, res) => {
    const users = await db.User.findAll({ include: [db.Role, db.Position] });
    res.json(users);
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});